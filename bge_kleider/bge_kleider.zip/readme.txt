BGE_kleider 
- Wordpress-Theme for websites of the BGE Party
====================================================

Version 3.3.15 by Arnold Schiller (arno), 03.10.2016



DOWNLOADS

    GITHub-Repo:
        https://github.com/b-grundeinkommen	
    
    Project-Website (Releases):
        http://www.bgeserver.de
    

AUTHOR 

   Arnold Schiller , http://arnold-schiller.de , E-Mail: as@b-ge.de


CREDITS & COPYRIGHT

   GNU General Public License (GPL) Version 2 


   Sources:
     - Pictures "Wikings" and "Sailing Ship": Wolfgang Wiese publiced unter GPL
     - Social Media Icons: Paul Robert Lloyd, http://paulrobertlloyd.com/2009/06/social_media_icons      
     - jQuery FlexSlider 2 (GPL v2)
     - Font Bebas Neue by Dharmatype (SIL Open Font License 1.1)
     - Font Droid Sans by Ascender (http://www.droidfonts.com/), Apache License 2.0 http://www.apache.org/licenses/LICENSE-2.0
     - Font Awesome http://fontawesome.io by Dave Gandy (SIL Open Font License 1.1)
     - Font Politics Head by SG Gestaltung (WTFPL Lizenz, http://de.wikipedia.org/wiki/WTFPL) 
     - Other pictures: Wiki of the german BGE party, published 
         as public domain, GPL or creative commons 

FEEDBACK & BUGS

Please use github for submitting new features or bugs:
 https://github.com/xwolfde/BGE_kleider/issues

Alternative, you can also use comments on the project page 
 http://www.bgeserver.de
or send an email to 
 info@b-ge.de


PRERELEASES

This theme bases on piratenkleider 2 

