Special Template-overwrites in use of plugin 'the-events-calendar'.

